// Toggle dropdown menu
document.querySelector('.hamburger-menu').addEventListener('click', function(e) {
    e.preventDefault();
    const dropdown = document.querySelector('.dropdown');
    dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
});

// Handle send post button
document.querySelector('.send-post-btn').addEventListener('click', function() {
    const postInput = document.querySelector('.post-input');
    if (postInput.value.trim()) {
        alert('Post sent: ' + postInput.value);
        postInput.value = '';
    } else {
        alert('Please write something to post!');
    }
});

// Handle prediction button
document.querySelector('.prediction-btn').addEventListener('click', function() {
    alert('Make your prediction here!');
});